import Link from "next/link";

export default function Home() {
  return (
    <main className="min-h-screen">
      <section className="px-6 md:px-10 lg:px-16 py-16 md:py-24 border-b border-white/10 bg-gradient-to-b from-black/10 to-black/0">
        <div className="max-w-6xl mx-auto">
          <div className="inline-flex items-center gap-2 rounded-full border border-white/10 px-3 py-1 text-xs text-white/70">
            <span className="h-2 w-2 rounded-full bg-emerald-400 animate-pulse" />
            Fase Alpha pública
          </div>
          <h1 className="mt-6 text-4xl md:text-6xl font-bold tracking-tight">
            ChronosToken <span className="text-chronos-primary">tokeniza</span> tu tiempo
          </h1>
          <p className="mt-4 max-w-2xl text-white/70 text-lg">
            Gestiona, intercambia y canjea horas productivas con un token de utilidad sencillo.
            Transparente, útil y orientado a la adopción real.
          </p>

          <div className="mt-8 flex flex-col sm:flex-row gap-3">
            <a className="rounded-xl bg-chronos-primary px-5 py-3 font-medium hover:opacity-90 transition"
               href="mailto:chronostoken@chronostoken.org?subject=Quiero%20unirme%20a%20la%20lista%20de%20espera">
              Unirme a la lista de espera
            </a>
            <Link href="#como-funciona"
              className="rounded-xl border border-white/20 px-5 py-3 font-medium hover:bg-white/5 transition text-center">
              ¿Cómo funciona?
            </Link>
          </div>
        </div>
      </section>

      <section className="px-6 md:px-10 lg:px-16 py-16">
        <div className="max-w-6xl mx-auto grid md:grid-cols-3 gap-6">
          {[{ title: "Tiempo = valor", desc: "Cada token representa tiempo de trabajo/servicio con reglas claras." },
            { title: "Economía real", desc: "Utilidad directa: reserva, canjea y audita con métricas de productividad." },
            { title: "Fricción mínima", desc: "Onboarding por email y custodio; sin exigir cripto a nuevos usuarios." }]
            .map((c, i) => (
            <div key={i} className="rounded-2xl border border-white/10 p-6 bg-white/5">
              <h3 className="font-semibold text-lg">{c.title}</h3>
              <p className="mt-2 text-white/70">{c.desc}</p>
            </div>
          ))}
        </div>
      </section>

      <section id="como-funciona" className="px-6 md:px-10 lg:px-16 py-16 border-t border-white/10">
        <div className="max-w-5xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold">¿Cómo funciona?</h2>
          <ol className="mt-6 space-y-4 text-white/80 list-decimal list-inside">
            <li>Compra o gana <strong>CHRONOS</strong> (unidades de tiempo).</li>
            <li>Reserva horas con profesionales/servicios que aceptan CHRONOS.</li>
            <li>Canjea el servicio y califica la productividad; las métricas alimentan la reputación.</li>
          </ol>
          <p className="mt-6 text-white/60">
            Todo comienza con una utilidad clara: gestionar y canjear <em>tiempo</em>.
          </p>
        </div>
      </section>

      <section className="px-6 md:px-10 lg:px-16 py-16">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold">Roadmap breve</h2>
          <div className="mt-6 grid md:grid-cols-3 gap-6">
            {[{ phase: "Q4", title: "MVP", items: ["Landing + lista de espera", "Piloto horas tokenizadas", "Validación de UX"] },
              { phase: "Q1", title: "Beta", items: ["Wallet custodio", "Reserva/agenda", "Payouts a proveedores"] },
              { phase: "Q2", title: "Escala", items: ["Marketplace", "SDK partners", "Normativa & Compliance"] }]
              .map((c, i) => (
              <div key={i} className="rounded-2xl border border-white/10 p-6 bg-white/5">
                <div className="text-sm text-white/50">{c.phase}</div>
                <h3 className="mt-1 font-semibold">{c.title}</h3>
                <ul className="mt-2 list-disc list-inside text-white/70 space-y-1">
                  {c.items.map((it, j) => <li key={j}>{it}</li>)}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="px-6 md:px-10 lg:px-16 py-16 border-t border-white/10">
        <div className="max-w-6xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
          <div>
            <h3 className="text-2xl font-semibold">¿Te interesa colaborar o invertir?</h3>
            <p className="text-white/70">Escríbenos y te enviamos el one-pager y acceso al piloto.</p>
          </div>
          <a className="rounded-xl bg-white text-black px-6 py-3 font-semibold hover:bg-white/90 transition"
             href="mailto:chronostoken@chronostoken.org?subject=Contacto%20ChronosToken">
            Contactar
          </a>
        </div>
      </section>

      <footer className="px-6 md:px-10 lg:px-16 py-10 border-t border-white/10 text-sm text-white/50">
        <div className="max-w-6xl mx-auto flex flex-col md:flex-row items-center justify-between gap-3">
          <span>© {new Date().getFullYear()} ChronosToken · Jon Imanol Aguayo Talavera</span>
          <div className="flex gap-4">
            <a className="hover:text-white" href="mailto:chronostoken@chronostoken.org">Email</a>
            <a className="hover:text-white" href="#">X/Twitter</a>
            <a className="hover:text-white" href="#">LinkedIn</a>
          </div>
        </div>
      </footer>
    </main>
  );
}