import "./globals.css";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "ChronosToken — Tokeniza tu tiempo",
  description: "El token de utilidad para gestionar y canjear tiempo productivo.",
  metadataBase: new URL("https://chronostoken.org")
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="es">
      <body className="bg-chronos-dark text-white">{children}</body>
    </html>
  );
}