# ChronosToken Starter (Next.js + Tailwind)

Landing minimal lista para desplegar en **Vercel** con **Cloudflare DNS** y **correo en DreamHost**.

## Despliegue rápido
1. Descarga este ZIP y descomprímelo.
2. Entra a la carpeta y ejecuta:
   ```bash
   npm i
   npm run dev
   ```
3. **Vercel**: crea un proyecto nuevo e importa este repo (o usa `vercel` CLI).
   En *Settings → Domains* añade `chronostoken.org` y `www.chronostoken.org`.

4. **Cloudflare DNS** (Zona: chronostoken.org):
   - A  @  ->  76.76.21.21   (Proxy OFF al principio)
   - CNAME  www  ->  cname.vercel-dns.com  (Proxy OFF)
   - MX @ -> mx1.mailchannels.net (prio 0)
   - MX @ -> mx2.mailchannels.net (prio 0)
   - CNAME autoconfig -> autoconfig.dreamhost.com
   - TXT @ -> v=spf1 mx include:netblocks.dreamhost.com include:relay.mailchannels.net -all
   - TXT dreamhost._domainkey -> (valor DKIM de DreamHost)
   - TXT _dmarc -> v=DMARC1; p=quarantine; sp=quarantine; rua=mailto:dmarc@chronostoken.org; ruf=mailto:dmarc@chronostoken.org; pct=100; adkim=s; aspf=s; fo=1

5. Cuando Vercel tenga SSL OK, puedes (opcional) activar Proxy en Cloudflare.

© Jon Imanol Aguayo Talavera — ChronosToken
